tokens = [
    'COMENTARIO',
    'IDENTIFICADOR',
    'CONSTANTE_ENTERA',
    'INCREMENTO',
    'OPERADOR_ARITMETICO',
    'OPERADOR_LOGICO',
    'ASIGNACION',
    'SEPARACION',
    'MODIFICADOR'
]

reservado = {
   'si' : 'SI',
   'sino' : 'SINO',
   'otros' : 'OTROS',
   'para': 'PARA',
   'mientras': 'MIENTRAS',
   'tocar': 'TOCAR',
   'funcion': 'FUNCION',
   'do': 'DO',
   're': 'RE',
   'mi': 'MI',
   'fa': 'FA',
   'sol': 'SOL',
   'la': 'LA',
   'si': 'SI',
   'retorna': 'RETORNA',
   'piano': 'PIANO',
   'guitarra': 'GUITARRA',
   'flauta': 'FLAUTA',
}

tokens += list(reservado.values());

#Las siguientes son las expresiones regulares de cada clase lexica
def t_COMENTARIO(t):
    r'(/\*(.|\n)*?\*/)|(//.*)'
    t.lineno += t.value.count('\n')
    return t ##este esta solo para revisar, ya en produccion, esto se quita, no tiene caso que retornemos comentarios

def t_IDENTIFICADOR(t):
    #r'[a-zA-Z_][a-zA-Z_0-9]*'
    r'[a-zA-Z_]\w*'
    t.type = reservado.get(t.value,'IDENTIFICADOR')    # Check for reserved words
    return t

def t_CONSTANTE_ENTERA(t):
    r'[\+-\–]?\d+'
    t.value = int(t.value)
    return t

def t_INCREMENTO(t):
    r'[+][+]|[-][-]'
    return t

def t_OPERADOR_ARITMETICO(t):
    r'[\*|\+|\-|\/]'
    return t

def t_OPERADOR_LOGICO(t):
    r'[=][=]|[<][=]|[>][=]|[!][=]|[<>]'
    return t

def t_ASIGNACION(t):
    r'[=]'
    return t

def t_SEPARACION(t):
    r'\(|\)|\[|\]|\{|\}|\,'
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

t_ignore  = ' \t'

# Error handling rule
def t_error(t):
    #En teoria aqui tiene que llamar al manejador de errores pero pues no esta programdo jeje...
    print ("Caracter ilegal '%s'" % t.value[0])
    t.lexer.skip(1)
